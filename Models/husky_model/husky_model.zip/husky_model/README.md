# HBP Husky Model:

This folder contains a model of an extension of the Clearpath Husky A200 Robot Model for the HBP project. It is equiped with a 2D camera mounted on the front

The physical model is model.sdf and refers to the .dae file in its visual section.

To import the model in Gazebo, copy the virtual_room directory into ~/.gazebo/Models or run catkin_make install.

After starting Gazebo the model will be avaiable in the models list.





